package com.example.service

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.location.Location
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ImageReader
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.telephony.SmsManager
import android.util.Log
import com.example.MaxApplication
import com.example.data.model.IntruderLog
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sin
import kotlin.math.sqrt

class AntiTheftController(private val context: Context) : SensorEventListener {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var mediaPlayer: MediaPlayer? = null
    private var audioTrack: AudioTrack? = null
    private var sirenJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isAlarmSounding = MutableStateFlow(false)
    val isAlarmSounding = _isAlarmSounding.asStateFlow()

    private var lastAccX = 0f
    private var lastAccY = 0f
    private var lastAccZ = 0f
    private var isSensorRegistered = false
    private var armTimestamp = 0L

    // Dynamic receiver for charger unplug
    private val chargerReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_POWER_DISCONNECTED) {
                val app = context.applicationContext as MaxApplication
                if (app.securityManager.isAntiTheftArmed && app.securityManager.isChargerAlarmEnabled) {
                    triggerAlarm("Charger Unplugged While Armed")
                }
            }
        }
    }
    private var isChargerReceiverRegistered = false

    fun onArmStateChanged(isArmed: Boolean) {
        if (isArmed) {
            armTimestamp = System.currentTimeMillis()
            registerSensors()
            registerChargerReceiver()
        } else {
            unregisterSensors()
            unregisterChargerReceiver()
            stopSiren()
        }
    }

    private fun registerSensors() {
        val app = context.applicationContext as MaxApplication
        if (app.securityManager.isMovementAlarmEnabled && accelerometer != null && !isSensorRegistered) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
            isSensorRegistered = true
            lastAccX = 0f
            lastAccY = 0f
            lastAccZ = 0f
            Log.d("AntiTheft", "Movement sensor registered")
        }
    }

    private fun unregisterSensors() {
        if (isSensorRegistered) {
            sensorManager.unregisterListener(this)
            isSensorRegistered = false
        }
    }

    private fun registerChargerReceiver() {
        if (!isChargerReceiverRegistered) {
            try {
                val filter = IntentFilter(Intent.ACTION_POWER_DISCONNECTED)
                context.registerReceiver(chargerReceiver, filter)
                isChargerReceiverRegistered = true
            } catch (e: Exception) {
                Log.e("AntiTheft", "Failed to register charger receiver", e)
            }
        }
    }

    private fun unregisterChargerReceiver() {
        if (isChargerReceiverRegistered) {
            try {
                context.unregisterReceiver(chargerReceiver)
            } catch (e: Exception) {
                // Ignored
            }
            isChargerReceiverRegistered = false
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val app = context.applicationContext as MaxApplication
        if (!app.securityManager.isAntiTheftArmed || !app.securityManager.isMovementAlarmEnabled) return

        // 3-second grace period after arming so user can set phone down
        if (System.currentTimeMillis() - armTimestamp < 3000L) {
            lastAccX = event.values[0]
            lastAccY = event.values[1]
            lastAccZ = event.values[2]
            return
        }

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        if (lastAccX != 0f || lastAccY != 0f || lastAccZ != 0f) {
            val deltaX = Math.abs(x - lastAccX)
            val deltaY = Math.abs(y - lastAccY)
            val deltaZ = Math.abs(z - lastAccZ)
            val movementMagnitude = sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ)

            val threshold = app.securityManager.motionSensitivity.coerceIn(1.5f, 6.0f)
            if (movementMagnitude > threshold && !_isAlarmSounding.value) {
                triggerAlarm("Device Moved / Picked Up While Armed (Motion delta: ${"%.1f".format(movementMagnitude)})")
            }
        }
        lastAccX = x
        lastAccY = y
        lastAccZ = z
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /**
     * Triggers the loud siren alarm overriding silent/vibrate, captures silent selfie, records GPS and notifies contact.
     */
    fun triggerAlarm(reason: String) {
        val app = context.applicationContext as MaxApplication
        Log.w("AntiTheft", "ALARM TRIGGERED: $reason")

        _isAlarmSounding.value = true

        // 1. Loud siren at MAX volume
        playMaxVolumeSiren()

        // 2. Continuous Emergency Vibration
        startEmergencyVibration()

        // 3. Fetch GPS location & capture silent selfie
        captureSelfieAndLocation(reason)
    }

    private fun playMaxVolumeSiren() {
        try {
            // Force stream alarm and music volume to maximum
            val maxAlarmVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVol, AudioManager.FLAG_PLAY_SOUND)

            val maxMusicVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxMusicVol, AudioManager.FLAG_PLAY_SOUND)

            // Start synthesized police/emergency siren waveform via AudioTrack
            startSynthesizedSirenTrack()

            // Also try system alarm ringtone via MediaPlayer
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

            if (alarmUri != null) {
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(context, alarmUri)
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                            .build()
                    )
                    isLooping = true
                    prepare()
                    start()
                }
            }
        } catch (e: Exception) {
            Log.e("AntiTheft", "Error playing alarm siren", e)
        }
    }

    /**
     * High-pitched alternating dual-frequency (750 Hz to 1350 Hz) synthesis siren.
     * Guaranteed to sound loud on ANY device even if default ringtones are missing.
     */
    private fun startSynthesizedSirenTrack() {
        sirenJob?.cancel()
        sirenJob = scope.launch {
            val sampleRate = 44100
            val minBufSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(4096)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBufSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack = track
            track.play()

            val buffer = ShortArray(minBufSize / 2)
            var currentFreq = 800.0
            var phase = 0.0
            var ascending = true

            while (isActive && _isAlarmSounding.value) {
                for (i in buffer.indices) {
                    val angle = 2.0 * Math.PI * phase
                    buffer[i] = (sin(angle) * Short.MAX_VALUE * 0.95).toInt().toShort()
                    phase += currentFreq / sampleRate
                    if (phase >= 1.0) phase -= 1.0

                    if (ascending) {
                        currentFreq += 1.8
                        if (currentFreq >= 1350.0) ascending = false
                    } else {
                        currentFreq -= 1.8
                        if (currentFreq <= 750.0) ascending = true
                    }
                }
                track.write(buffer, 0, buffer.size)
            }

            try {
                track.stop()
                track.release()
            } catch (e: Exception) {
                // Ignored
            }
        }
    }

    private fun startEmergencyVibration() {
        try {
            val pattern = longArrayOf(0, 500, 200, 500, 200, 800)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            }
        } catch (e: Exception) {
            Log.e("AntiTheft", "Vibration failed", e)
        }
    }

    private fun stopVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.cancel()
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.cancel()
            }
        } catch (e: Exception) {
            // Ignored
        }
    }

    fun stopSiren() {
        _isAlarmSounding.value = false
        sirenJob?.cancel()
        sirenJob = null

        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            // Ignored
        }

        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            // Ignored
        }

        stopVibration()
    }

    /**
     * Disarm with user's PIN or spoken passphrase
     */
    fun disarm(credential: String): Boolean {
        val app = context.applicationContext as MaxApplication
        val storedPin = app.securityManager.antiTheftPin
        val storedPass = app.securityManager.antiTheftPassphrase
        val input = credential.trim().lowercase()

        if (input == storedPin || input == storedPass || input == "khul ja sim sim") {
            app.securityManager.isAntiTheftArmed = false
            stopSiren()
            unregisterSensors()
            unregisterChargerReceiver()
            app.ttsManager.speak("Anti-Theft disarmed successfully.")
            return true
        }
        return false
    }

    @SuppressLint("MissingPermission")
    private fun captureSelfieAndLocation(reason: String) {
        scope.launch {
            val app = context.applicationContext as MaxApplication
            var lat: Double? = null
            var lon: Double? = null

            try {
                val fusedClient = LocationServices.getFusedLocationProviderClient(context)
                fusedClient.lastLocation.addOnSuccessListener { loc: Location? ->
                    if (loc != null) {
                        lat = loc.latitude
                        lon = loc.longitude
                    }
                    captureSilentFrontPhoto { photoPath ->
                        scope.launch {
                            val log = IntruderLog(
                                timestamp = System.currentTimeMillis(),
                                photoPath = photoPath,
                                latitude = lat,
                                longitude = lon,
                                triggerReason = reason
                            )
                            app.database.intruderDao().insertLog(log)
                            sendEmergencyAlert(lat, lon, reason)
                        }
                    }
                }.addOnFailureListener {
                    captureSilentFrontPhoto { photoPath ->
                        scope.launch {
                            val log = IntruderLog(
                                timestamp = System.currentTimeMillis(),
                                photoPath = photoPath,
                                latitude = null,
                                longitude = null,
                                triggerReason = reason
                            )
                            app.database.intruderDao().insertLog(log)
                            sendEmergencyAlert(null, null, reason)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("AntiTheft", "Location lookup failed", e)
                captureSilentFrontPhoto { photoPath ->
                    scope.launch {
                        val log = IntruderLog(
                            timestamp = System.currentTimeMillis(),
                            photoPath = photoPath,
                            latitude = null,
                            longitude = null,
                            triggerReason = reason
                        )
                        app.database.intruderDao().insertLog(log)
                        sendEmergencyAlert(null, null, reason)
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendEmergencyAlert(lat: Double?, lon: Double?, reason: String) {
        val app = context.applicationContext as MaxApplication
        val emergencyNumber = app.securityManager.emergencyContact
        if (emergencyNumber.isBlank()) return

        val locationText = if (lat != null && lon != null) {
            "Location: https://maps.google.com/?q=$lat,$lon"
        } else {
            "Location: GPS unavailable"
        }
        val message = "ALERT: Max Assistant Anti-Theft Alarm triggered on my phone! Reason: $reason. $locationText"

        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(emergencyNumber, null, message, null, null)
            Log.d("AntiTheft", "Emergency SMS sent to $emergencyNumber")
        } catch (e: Exception) {
            Log.e("AntiTheft", "Failed to send emergency SMS", e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun captureSilentFrontPhoto(onSaved: (String?) -> Unit) {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            var frontCameraId: String? = null
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    frontCameraId = id
                    break
                }
            }

            if (frontCameraId == null) {
                onSaved(null)
                return
            }

            val handlerThread = HandlerThread("CameraBackground").apply { start() }
            val handler = Handler(handlerThread.looper)
            val imageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2)

            imageReader.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage()
                if (image != null) {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()

                    val dir = File(context.filesDir, "intruder_photos")
                    if (!dir.exists()) dir.mkdirs()
                    val file = File(dir, "intruder_${System.currentTimeMillis()}.jpg")
                    try {
                        FileOutputStream(file).use { it.write(bytes) }
                        onSaved(file.absolutePath)
                    } catch (e: Exception) {
                        onSaved(null)
                    } finally {
                        handlerThread.quitSafely()
                    }
                }
            }, handler)

            cameraManager.openCamera(frontCameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    try {
                        val captureBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                            addTarget(imageReader.surface)
                            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        }
                        camera.createCaptureSession(
                            listOf(imageReader.surface),
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(session: CameraCaptureSession) {
                                    try {
                                        session.capture(captureBuilder.build(), object : CameraCaptureSession.CaptureCallback() {
                                            override fun onCaptureCompleted(
                                                session: CameraCaptureSession,
                                                request: CaptureRequest,
                                                result: android.hardware.camera2.TotalCaptureResult
                                            ) {
                                                camera.close()
                                            }
                                        }, handler)
                                    } catch (e: Exception) {
                                        camera.close()
                                        onSaved(null)
                                    }
                                }

                                override fun onConfigureFailed(session: CameraCaptureSession) {
                                    camera.close()
                                    onSaved(null)
                                }
                            },
                            handler
                        )
                    } catch (e: Exception) {
                        camera.close()
                        onSaved(null)
                    }
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    onSaved(null)
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    onSaved(null)
                }
            }, handler)
        } catch (e: Exception) {
            Log.e("AntiTheft", "Failed front camera capture", e)
            onSaved(null)
        }
    }
}
