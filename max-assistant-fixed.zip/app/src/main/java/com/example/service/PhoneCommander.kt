package com.example.service

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import com.example.MaxApplication
import com.example.data.model.ChatMessage
import com.example.data.model.PendingAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.Locale

class PhoneCommander(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _pendingAction = MutableStateFlow<PendingAction?>(null)
    val pendingAction = _pendingAction.asStateFlow()

    val navigationEvents = kotlinx.coroutines.flow.MutableSharedFlow<String>(extraBufferCapacity = 5)

    private var isTorchOn = false

    fun postPendingConfirmation(action: PendingAction) {
        _pendingAction.value = action
        val app = context.applicationContext as MaxApplication
        app.ttsManager.speak(action.spokenPrompt)
    }

    fun clearPendingConfirmation() {
        _pendingAction.value = null
    }

    fun confirmPendingAction() {
        val action = _pendingAction.value ?: return
        _pendingAction.value = null
        val app = context.applicationContext as MaxApplication

        when (action.actionType) {
            "whatsapp_send" -> {
                val recipient = action.recipient.orEmpty()
                val text = action.messageText.orEmpty()
                val sbnKey = WhatsAppNotificationListener.replyActions.keys.firstOrNull { it.contains(recipient, ignoreCase = true) }
                if (sbnKey != null && WhatsAppNotificationListener.instance?.sendDirectReply(sbnKey, text) == true) {
                    app.ttsManager.speak("Message bhej diya gaya hai.")
                } else {
                    // Fallback to WhatsApp intent
                    openWhatsAppMessage(recipient, text)
                    app.ttsManager.speak("WhatsApp khol diya hai, message ready hai.")
                }
            }
            "phone_call" -> {
                val phone = action.phoneNumber.orEmpty()
                makeDirectPhoneCall(phone)
            }
            "siren_disarm" -> {
                app.antiTheftController.stopSiren()
                app.securityManager.isAntiTheftArmed = false
                app.ttsManager.speak("Siren band ho gaya hai aur security disarm ho gayi hai.")
            }
        }
    }

    fun rejectPendingAction() {
        _pendingAction.value = null
        val app = context.applicationContext as MaxApplication
        app.ttsManager.speak("Theek hai Boss, cancel kar diya.")
    }

    /**
     * Central entry point for processing speech command in Hindi, English, and Hinglish.
     */
    fun processVoiceCommand(input: String) {
        val app = context.applicationContext as MaxApplication
        val boss = app.securityManager.userCallName
        val normalized = input.trim()
        val lower = normalized.lowercase(Locale.ROOT)

        Log.d("PhoneCommander", "Processing voice command: $normalized")

        // 1. Pending Action Confirmation check (Yes / Haan / Cancel)
        val pending = _pendingAction.value
        if (pending != null) {
            if (isAffirmative(lower)) {
                confirmPendingAction()
                return
            } else if (isNegative(lower)) {
                rejectPendingAction()
                return
            }
        }

        // 2. Interruption / Stop command
        if (lower == "chup" || lower == "chup raho" || lower == "stop" || lower == "ruk jao" || lower == "pause") {
            app.ttsManager.stop()
            app.antiTheftController.stopSiren()
            return
        }

        // 3. Anti-Theft Arm / Disarm
        if (lower.contains("anti theft on") || lower.contains("security on") || lower.contains("suraksha on") ||
            lower.contains("alarm arm") || lower.contains("phone ki suraksha chalu karo") || lower.contains("arm phone")
        ) {
            app.securityManager.isAntiTheftArmed = true
            app.antiTheftController.onArmStateChanged(true)
            app.ttsManager.speak("$boss, Anti-Theft security arm ho chuki hai. Koi bhi phone hilayega ya galat PIN dalega toh siren bajega.")
            return
        }

        if (lower.contains("disarm") || lower.contains("anti theft off") || lower.contains("suraksha band") || lower.contains("siren band")) {
            postPendingConfirmation(
                PendingAction(
                    actionType = "siren_disarm",
                    description = "Disarm Anti-Theft and silence siren",
                    spokenPrompt = "$boss, kya aap anti-theft security disarm karna chahte hain?"
                )
            )
            return
        }

        // Camera Vision Voice Commands: "ye kya hai", "kya hai ye", "camera vision kholo", "dawaai check karo"
        if (lower.contains("ye kya hai") || lower.contains("kya hai ye") || lower.contains("what is this") ||
            lower.contains("camera vision") || lower.contains("vision kholo") || lower.contains("ye dekho") ||
            lower.contains("currency pehchano") || lower.contains("dawaai padho")
        ) {
            navigationEvents.tryEmit("VISION")
            app.ttsManager.speak("$boss, Camera Vision khol diya hai. Frame ke saamne rakhein aur dekhein.")
            return
        }

        // Intruder Logs: "kisne phone chhua", "intruder log dikhao", "selfie dikhao"
        if (lower.contains("intruder log") || lower.contains("kisne phone chhua") || lower.contains("selfie dikhao") || lower.contains("chor ki photo")) {
            navigationEvents.tryEmit("INTRUDER_LOGS")
            app.ttsManager.speak("$boss, Intruder selfi aur logs screen khol di hai.")
            return
        }

        // 4. Multi-step task: e.g. "YouTube kholo aur Arijit Singh ka gaana lagao"
        if (lower.contains(" aur ") || lower.contains(" and ") || lower.contains(" then ")) {
            val steps = if (lower.contains(" aur ")) lower.split(" aur ") else if (lower.contains(" and ")) lower.split(" and ") else lower.split(" then ")
            if (steps.size > 1) {
                scope.launch {
                    processVoiceCommand(steps[0].trim())
                    kotlinx.coroutines.delay(2000)
                    processVoiceCommand(steps[1].trim())
                }
                return
            }
        }

        // 5. WhatsApp Voice & Text Bot Commands
        // Pattern: "<name> ko WhatsApp par message bhejo <text>"
        val waMatch = Regex("(.*?) ko whatsapp (par|pe)?\\s*(message|msg)?\\s*bhejo\\s*(.*)", RegexOption.IGNORE_CASE).find(lower)
            ?: Regex("send whatsapp message to (.*?):?\\s*(.*)", RegexOption.IGNORE_CASE).find(lower)

        if (waMatch != null) {
            val recipient = waMatch.groupValues[1].replace("whatsapp", "").trim()
            val messageText = waMatch.groupValues[waMatch.groupValues.size - 1].trim()
            if (recipient.isNotBlank() && messageText.isNotBlank()) {
                postPendingConfirmation(
                    PendingAction(
                        actionType = "whatsapp_send",
                        description = "WhatsApp to $recipient: \"$messageText\"",
                        spokenPrompt = "$boss, $recipient ko WhatsApp par message bhejna hai: \"$messageText\". Bhej doon?",
                        recipient = recipient,
                        messageText = messageText
                    )
                )
                return
            }
        }

        // WhatsApp call: "WhatsApp call lagao <name>"
        if (lower.contains("whatsapp call") || lower.contains("whatsapp par call")) {
            val contactName = lower.replace("whatsapp call", "")
                .replace("whatsapp par call lagao", "")
                .replace("whatsapp call karo", "")
                .replace("ko", "").trim()
            openWhatsAppContact(contactName)
            app.ttsManager.speak("$boss, $contactName ke liye WhatsApp khol diya hai.")
            return
        }

        // Chat summary: "is chat ka summary batao"
        if (lower.contains("summary") || lower.contains("chat ka summary") || lower.contains("chat summarize karo")) {
            scope.launch {
                val apiKey = app.securityManager.geminiApiKey
                if (apiKey.isBlank()) {
                    app.ttsManager.speak("Boss, chat summarize karne ke liye Settings mein Gemini API key daalein.")
                    return@launch
                }
                val messages = app.database.chatDao().getAllMessages()
                val transcript = "User: Hello\nAssistant: Welcome Boss\nRecent incoming notifications received on device."
                val summary = app.geminiService.summarizeChat(transcript, apiKey)
                summary.onSuccess { text ->
                    app.ttsManager.speak(text)
                }.onFailure {
                    app.ttsManager.speak("Summary nahi ban paya: ${it.message}")
                }
            }
            return
        }

        // 6. Screen OCR Click: "jis par <text> likha hai usko dabao" / "tap on <text>"
        val ocrMatch = Regex("jis par ['\"]?(.*?)['\"]? likha hai usko dabao", RegexOption.IGNORE_CASE).find(lower)
            ?: Regex("(click|tap on|press|dabao) ['\"]?(.*?)['\"]?", RegexOption.IGNORE_CASE).find(lower)

        if (ocrMatch != null && (lower.contains("likha hai") || lower.contains("tap on") || lower.contains("click"))) {
            val target = ocrMatch.groupValues[ocrMatch.groupValues.size - 1]
                .replace("likha hai usko dabao", "")
                .replace("dabao", "")
                .trim()

            if (target.isNotBlank()) {
                val accessibility = MaxAccessibilityService.instance
                if (accessibility != null) {
                    accessibility.clickTextViaOcr(target) { success, msg ->
                        app.ttsManager.speak(msg)
                    }
                } else {
                    app.ttsManager.speak("Boss, kripya Accessibility permission on karein.")
                }
                return
            }
        }

        // 7. Screen Understanding: "is screen par kya hai"
        if (lower.contains("screen par kya hai") || lower.contains("what is on this screen") || lower.contains("explain screen")) {
            val accessibility = MaxAccessibilityService.instance
            if (accessibility != null) {
                app.ttsManager.speak("Screen check kar raha hoon...")
                accessibility.captureCurrentScreen { bitmap ->
                    if (bitmap != null) {
                        scope.launch {
                            val apiKey = app.securityManager.geminiApiKey
                            if (apiKey.isBlank()) {
                                app.ttsManager.speak("Boss, vision ke liye Settings mein Gemini API key set karein.")
                                return@launch
                            }
                            val res = app.geminiService.understandScreen(bitmap, apiKey)
                            res.onSuccess { text ->
                                app.ttsManager.speak(text)
                            }.onFailure {
                                app.ttsManager.speak("Screen samajhne mein dikkat hui: ${it.message}")
                            }
                        }
                    } else {
                        app.ttsManager.speak("Screen capture nahi ho paya.")
                    }
                }
            } else {
                app.ttsManager.speak("Accessibility service chalu nahi hai.")
            }
            return
        }

        // 8. YouTube Voice Commands: "YouTube par <song> lagao"
        if (lower.contains("youtube par") || lower.contains("play on youtube") || (lower.contains("youtube") && lower.contains("lagao"))) {
            val query = lower.replace("youtube par", "")
                .replace("gaana lagao", "")
                .replace("video lagao", "")
                .replace("lagao", "")
                .replace("chalao", "")
                .replace("play", "")
                .trim()
            openYouTubeSearch(query)
            app.ttsManager.speak("$boss, YouTube par $query chala diya hai.")
            return
        }

        // 9. Instagram Controls: "Instagram kholo", "reels chalao", "next reel"
        if (lower.contains("instagram")) {
            openAppByName("Instagram")
            app.ttsManager.speak("Instagram open kar diya hai.")
            return
        }
        if (lower.contains("next reel") || lower.contains("agla reel")) {
            MaxAccessibilityService.instance?.swipeNextReel()
            return
        }
        if (lower.contains("previous reel") || lower.contains("pichhla reel")) {
            MaxAccessibilityService.instance?.swipePreviousReel()
            return
        }
        if (lower.contains("like reel") || lower.contains("like karo")) {
            MaxAccessibilityService.instance?.doubleTapLike()
            app.ttsManager.speak("Reel like kar di.")
            return
        }

        // 10. System Navigation Gestures
        if (lower == "home" || lower == "home jao" || lower == "go home") {
            MaxAccessibilityService.instance?.triggerHome()
            return
        }
        if (lower == "back" || lower == "piche jao" || lower == "go back") {
            MaxAccessibilityService.instance?.triggerBack()
            return
        }
        if (lower == "recents" || lower == "recent apps") {
            MaxAccessibilityService.instance?.triggerRecents()
            return
        }
        if (lower.contains("lock screen") || lower.contains("phone lock karo")) {
            MaxAccessibilityService.instance?.triggerLockScreen()
            return
        }
        if (lower.contains("screenshot lo") || lower.contains("take screenshot")) {
            MaxAccessibilityService.instance?.triggerScreenshot()
            app.ttsManager.speak("Screenshot le liya hai.")
            return
        }
        if (lower.contains("scroll up") || lower.contains("upar karo")) {
            MaxAccessibilityService.instance?.scrollUp()
            return
        }
        if (lower.contains("scroll down") || lower.contains("neeche karo")) {
            MaxAccessibilityService.instance?.scrollDown()
            return
        }

        // 11. Hardware Controls: Flashlight, Volume, WiFi, Bluetooth
        if (lower.contains("flashlight on") || lower.contains("torch on") || lower.contains("torch jalao")) {
            setTorch(true)
            app.ttsManager.speak("Torch on kar di.")
            return
        }
        if (lower.contains("flashlight off") || lower.contains("torch off") || lower.contains("torch band")) {
            setTorch(false)
            app.ttsManager.speak("Torch band kar di.")
            return
        }
        if (lower.contains("volume up") || lower.contains("awaz badhao")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            app.ttsManager.speak("Volume badha diya.")
            return
        }
        if (lower.contains("volume down") || lower.contains("awaz kam karo")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            app.ttsManager.speak("Volume kam kar diya.")
            return
        }
        if (lower.contains("mute") || lower.contains("silent karo")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            app.ttsManager.speak("Phone silent kar diya.")
            return
        }
        if (lower.contains("bluetooth on") || lower.contains("bluetooth open")) {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            app.ttsManager.speak("Bluetooth settings khol di hai.")
            return
        }
        if (lower.contains("wifi on") || lower.contains("wifi open") || lower.contains("wi-fi")) {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            app.ttsManager.speak("Wi-Fi settings khol di hai.")
            return
        }

        // 12. App Launching by Name: "<App Name> kholo" / "open <App Name>"
        if (lower.contains("kholo") || lower.contains("open") || lower.contains("chalu karo")) {
            val appQuery = lower.replace("kholo", "")
                .replace("open", "")
                .replace("chalu karo", "")
                .replace("app", "")
                .trim()
            val launched = openAppByName(appQuery)
            if (launched) {
                app.ttsManager.speak("$boss, $appQuery khol diya hai.")
                return
            }
        }

        // 13. General AI conversation fallback via Gemini
        scope.launch {
            val apiKey = app.securityManager.geminiApiKey
            if (apiKey.isNotBlank()) {
                val sys = "You are ${app.securityManager.assistantName}, personal assistant for $boss. Reply naturally in concise Hinglish/Hindi/English."
                val response = app.geminiService.generateReply(normalized, emptyList(), sys, apiKey)
                response.onSuccess { reply ->
                    app.ttsManager.speak(reply)
                    app.database.chatDao().insertMessage(ChatMessage(sender = "assistant", text = reply))
                }.onFailure {
                    app.ttsManager.speak("$boss, mujhe samajh aa gaya par Gemini connect nahi ho paya: ${it.localizedMessage}")
                }
            } else {
                app.ttsManager.speak("$boss, main local phone control kar raha hoon. AI baatchit ke liye Settings mein Gemini API key set karein.")
            }
        }
    }

    private fun isAffirmative(text: String): Boolean {
        return text == "yes" || text == "haan" || text == "ha" || text == "bhej do" || text == "bhejo" ||
                text == "kar do" || text == "ok" || text == "theek hai" || text == "sure" || text.contains("haan")
    }

    private fun isNegative(text: String): Boolean {
        return text == "no" || text == "nahi" || text == "na" || text == "cancel" || text == "mat bhejo" || text == "ruk jao"
    }

    private fun setTorch(state: Boolean) {
        try {
            val id = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(id, state)
            isTorchOn = state
        } catch (e: Exception) {
            Log.e("PhoneCommander", "Torch error", e)
        }
    }

    private fun openAppByName(query: String): Boolean {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        val normalizedQuery = query.lowercase().replace(" ", "")

        var matchedPackage: String? = null
        for (info in resolveInfos) {
            val label = info.loadLabel(pm).toString().lowercase().replace(" ", "")
            if (label.contains(normalizedQuery) || normalizedQuery.contains(label)) {
                matchedPackage = info.activityInfo.packageName
                break
            }
        }

        if (matchedPackage != null) {
            val launchIntent = pm.getLaunchIntentForPackage(matchedPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return true
            }
        }
        return false
    }

    private fun openYouTubeSearch(query: String) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
            setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }

    private fun openWhatsAppContact(name: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("whatsapp://send")
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    private fun openWhatsAppMessage(recipient: String, message: String) {
        val encoded = URLEncoder.encode(message, "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?text=$encoded")
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val genericIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(genericIntent)
        }
    }

    @SuppressLint("MissingPermission")
    private fun makeDirectPhoneCall(phone: String) {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
        }
    }
}
