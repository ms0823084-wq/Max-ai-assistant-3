package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VoiceVisualizerWaves(
    isListening: Boolean,
    isSpeaking: Boolean,
    rmsDb: Float,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "voice_visualizer")

    val pulse1 by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse1"
    )

    val pulse2 by transition.animateFloat(
        initialValue = 1.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse2"
    )

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val energyBoost = (rmsDb.coerceIn(0f, 60f) / 60f) * 0.5f
    val dynamicScale = if (isListening) pulse1 + energyBoost else if (isSpeaking) pulse2 + 0.15f else 1.0f

    Box(
        modifier = modifier.size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.minDimension / 4f

            // Outer soundwave ring 1
            val r1 = (baseRadius * 1.6f * dynamicScale).coerceAtMost(size.minDimension / 2f - 4)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonCyan.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = r1
                ),
                radius = r1,
                center = center
            )
            drawCircle(
                color = NeonCyan.copy(alpha = if (isListening) 0.6f else 0.25f),
                radius = r1,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Outer ring 2 (Interlaced)
            val r2 = (baseRadius * 1.3f * (if (isSpeaking) pulse1 else pulse2)).coerceAtMost(size.minDimension / 2f - 8)
            drawCircle(
                color = if (isSpeaking) GoldenAmber.copy(alpha = 0.5f) else ElectricBlue.copy(alpha = 0.4f),
                radius = r2,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Inner glowing core orb
            val innerRadius = baseRadius * dynamicScale.coerceIn(0.8f, 1.25f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = if (isSpeaking) {
                        listOf(GoldenAmber, DarkSapphire)
                    } else if (isListening) {
                        listOf(NeonCyan, DarkSapphire)
                    } else {
                        listOf(ElectricBlue.copy(alpha = 0.8f), DarkSapphire)
                    },
                    center = center,
                    radius = innerRadius
                ),
                radius = innerRadius,
                center = center
            )

            // Dynamic neural wave points
            val pointCount = 12
            for (i in 0 until pointCount) {
                val angle = Math.toRadians((i * (360.0 / pointCount) + rotation))
                val waveOffset = (sin(angle * 3 + rotation) * 12 * dynamicScale).toFloat()
                val px = (center.x + (innerRadius + waveOffset) * cos(angle)).toFloat()
                val py = (center.y + (innerRadius + waveOffset) * sin(angle)).toFloat()
                drawCircle(
                    color = if (isSpeaking) GoldenAmber else NeonCyan,
                    radius = (3f + energyBoost * 4).dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }
    }
}
