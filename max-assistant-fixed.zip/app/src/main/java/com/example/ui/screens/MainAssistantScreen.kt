package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MaxApplication
import com.example.data.model.ChatMessage
import com.example.service.VoiceForegroundService
import com.example.speech.SpeechManager
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.VoiceVisualizerWaves
import com.example.ui.theme.BrightCoral
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainAssistantScreen(
    onNavigateToVision: () -> Unit,
    onNavigateToAntiTheft: () -> Unit,
    onNavigateToWhatsApp: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToLicense: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = context.applicationContext as MaxApplication
    val scope = rememberCoroutineScope()

    var isListening by remember { mutableStateOf(false) }
    var rmsLevel by remember { mutableFloatStateOf(0f) }
    var liveTranscript by remember { mutableStateOf("") }
    var alwaysListenServiceActive by remember { mutableStateOf(VoiceForegroundService.isRunning) }

    val messages by app.database.chatDao().getAllMessages().collectAsState(initial = emptyList())
    val pendingAction by app.phoneCommander.pendingAction.collectAsState()
    val isAlarmSounding by app.antiTheftController.isAlarmSounding.collectAsState()

    val wakeWord = app.securityManager.wakeWord
    val assistantName = app.securityManager.assistantName
    val bossName = app.securityManager.userCallName

    val speechManager = remember {
        SpeechManager(context, app.securityManager, object : SpeechManager.SpeechEventsListener {
            override fun onWakeWordDetected(keyword: String) {
                isListening = true
                liveTranscript = "Wake word detected: $keyword"
                app.ttsManager.speak("Haanji $bossName, bataiye?")
            }

            override fun onCommandRecognized(command: String) {
                isListening = false
                liveTranscript = command
                scope.launch {
                    app.database.chatDao().insertMessage(ChatMessage(sender = "user", text = command))
                    app.phoneCommander.processVoiceCommand(command)
                }
            }

            override fun onPartialSpeech(partial: String) {
                liveTranscript = partial
            }

            override fun onRmsChanged(rmsDb: Float) {
                rmsLevel = rmsDb
            }

            override fun onSpeechError(error: String) {
                isListening = false
            }

            override fun onListeningStateChanged(listening: Boolean) {
                isListening = listening
            }
        })
    }

    LaunchedEffect(Unit) {
        speechManager.initialize()
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavy)
    ) {
        // Top Status & Control Bar
        Surface(
            color = DeepSlate,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (alwaysListenServiceActive) EmeraldGreen else BrightCoral)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = assistantName.uppercase(),
                        fontWeight = FontWeight.ExtraBold,
                        color = NeonCyan,
                        fontSize = 16.sp,
                        letterSpacing = 1.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Always listening switch
                    Text(
                        text = "Hands-free",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Switch(
                        checked = alwaysListenServiceActive,
                        onCheckedChange = { checked ->
                            alwaysListenServiceActive = checked
                            val intent = Intent(context, VoiceForegroundService::class.java).apply {
                                action = if (checked) VoiceForegroundService.ACTION_START_LISTENING
                                else VoiceForegroundService.ACTION_STOP_LISTENING
                            }
                            if (checked) context.startForegroundService(intent)
                            else context.startService(intent)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = DarkSapphire
                        ),
                        modifier = Modifier.testTag("always_listen_switch")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Instant Kill Switch for Mic & Speech
                    IconButton(
                        onClick = {
                            app.ttsManager.stop()
                            speechManager.stopListening()
                            isListening = false
                            liveTranscript = ""
                            app.antiTheftController.stopSiren()
                            val intent = Intent(context, VoiceForegroundService::class.java).apply {
                                action = VoiceForegroundService.ACTION_STOP_LISTENING
                            }
                            context.startService(intent)
                            alwaysListenServiceActive = false
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BrightCoral.copy(alpha = 0.2f))
                            .testTag("mic_kill_switch")
                    ) {
                        Icon(
                            Icons.Default.Block,
                            contentDescription = "Instant Kill Switch",
                            tint = BrightCoral,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Alarm Alert Banner if siren is sounding
        AnimatedVisibility(visible = isAlarmSounding) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BrightCoral),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "SIREN ALARM TRIGGERED!",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Button(
                        onClick = { app.antiTheftController.stopSiren() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                    ) {
                        Text("Silence", color = BrightCoral, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Quick Sub-screen Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = SlateCard,
                modifier = Modifier.clickable { onNavigateToPermissions() }
            ) {
                Text(
                    text = "⚙️ Permissions Hub",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = SlateCard,
                modifier = Modifier.clickable { onNavigateToLicense() }
            ) {
                Text(
                    text = "🔑 License",
                    color = GoldenAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = SlateCard,
                modifier = Modifier.clickable { onNavigateToSettings() }
            ) {
                Text(
                    text = "🛡️ Privacy & Safety",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        // Center Voice Hologram Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.42f),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                VoiceVisualizerWaves(
                    isListening = isListening || alwaysListenServiceActive,
                    isSpeaking = app.ttsManager.isSpeaking,
                    rmsDb = rmsLevel
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Wake word pill
                Surface(
                    color = SlateCard,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "Say: \"$wakeWord\" or tap mic",
                        color = GoldenAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                if (liveTranscript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\"$liveTranscript\"",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
        }

        // Quick Command Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val chips = listOf(
                "YouTube par gaana lagao",
                "WhatsApp message bhejo",
                "is screen par kya hai",
                "Anti-Theft arm karo",
                "Torch on karo",
                "Next Reel",
                "Volume up"
            )
            for (chip in chips) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SlateCard,
                    modifier = Modifier.clickable {
                        speechManager.stopListening()
                        isListening = false
                        liveTranscript = chip
                        scope.launch {
                            app.database.chatDao().insertMessage(ChatMessage(sender = "user", text = chip))
                            app.phoneCommander.processVoiceCommand(chip)
                        }
                    }
                ) {
                    Text(
                        text = chip,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Chat Conversation Feed
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.40f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Ready to assist you, $bossName. Speak in Hindi, English or Hinglish.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
            items(messages, key = { it.id }) { msg ->
                val isUser = msg.sender == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        shape = RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 16.dp
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) DarkSapphire else SlateCard
                        ),
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .border(
                                1.dp,
                                if (isUser) ElectricBlue.copy(alpha = 0.5f) else NeonCyan.copy(alpha = 0.2f),
                                RoundedCornerShape(16.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = msg.text,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(msg.timestamp)),
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                                if (!isUser) {
                                    IconButton(
                                        onClick = { app.ttsManager.speak(msg.text) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.VolumeUp,
                                            contentDescription = "Read aloud",
                                            tint = NeonCyan,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Big Mic Floating Bar
        Surface(
            color = DeepSlate,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = if (isListening) listOf(GoldenAmber, BrightCoral)
                                else listOf(NeonCyan, DarkSapphire)
                            )
                        )
                        .clickable {
                            if (isListening) {
                                speechManager.stopListening()
                                isListening = false
                            } else {
                                app.ttsManager.stop()
                                isListening = true
                                speechManager.startListening()
                            }
                        }
                        .testTag("big_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                        contentDescription = "Microphone",
                        tint = if (isListening) Color.White else Color.Black,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }
        }
    }

    // Safety Confirmation Dialog for messages & calls
    pendingAction?.let { action ->
        ConfirmActionDialog(
            action = action,
            onConfirm = { app.phoneCommander.confirmPendingAction() },
            onCancel = { app.phoneCommander.rejectPendingAction() }
        )
    }
}
