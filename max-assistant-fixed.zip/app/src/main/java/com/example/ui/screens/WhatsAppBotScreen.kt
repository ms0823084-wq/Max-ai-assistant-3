package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MaxApplication
import com.example.service.WhatsAppMessageEvent
import com.example.service.WhatsAppNotificationListener
import com.example.ui.theme.BrightCoral
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WhatsAppBotScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = context.applicationContext as MaxApplication
    val scope = rememberCoroutineScope()

    var isAutoReplyOn by remember { mutableStateOf(app.securityManager.isWhatsAppAutoReplyEnabled) }
    var autoSendWithoutApproval by remember { mutableStateOf(app.securityManager.isAutoSendWithoutApproval) }
    var replyTone by remember { mutableStateOf(app.securityManager.autoReplyTone) }

    var manualSendRecipient by remember { mutableStateOf("") }
    var manualSendMessage by remember { mutableStateOf("") }

    var summaryText by remember { mutableStateOf<String?>(null) }
    var isSummarizing by remember { mutableStateOf(false) }

    val recentMessages by WhatsAppNotificationListener.incomingMessages.collectAsState(initial = null)
    val messageList = remember { mutableListOf<WhatsAppMessageEvent>() }

    recentMessages?.let {
        if (!messageList.any { m -> m.sbnKey == it.sbnKey && m.timestamp == it.timestamp }) {
            messageList.add(0, it)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Chat,
                    contentDescription = "WhatsApp Bot",
                    tint = EmeraldGreen,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "WHATSAPP VOICE & TEXT BOT",
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                    Text(
                        text = if (WhatsAppNotificationListener.isServiceRunning) "Listener Active" else "Enable Notification Access",
                        color = if (WhatsAppNotificationListener.isServiceRunning) EmeraldGreen else GoldenAmber,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Auto-Reply Settings Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, EmeraldGreen.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AI Auto-Reply Mode", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Gemini drafts replies automatically in your tone", color = TextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isAutoReplyOn,
                        onCheckedChange = {
                            isAutoReplyOn = it
                            app.securityManager.isWhatsAppAutoReplyEnabled = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = EmeraldGreen)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Send Automatically", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("Send without asking \"Boss, bhej doon?\"", color = BrightCoral, fontSize = 11.sp)
                    }
                    Switch(
                        checked = autoSendWithoutApproval,
                        onCheckedChange = {
                            autoSendWithoutApproval = it
                            app.securityManager.isAutoSendWithoutApproval = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = GoldenAmber)
                    )
                }

                OutlinedTextField(
                    value = replyTone,
                    onValueChange = {
                        replyTone = it
                        app.securityManager.autoReplyTone = it
                    },
                    label = { Text("Your Tone (e.g. friendly Hinglish, polite formal)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = EmeraldGreen,
                        unfocusedBorderColor = DarkSapphire
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Chat Summarizer Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DeepSlate),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Chat Summarizer", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "You can say: \"is chat ka summary batao\" anytime.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        isSummarizing = true
                        scope.launch {
                            val apiKey = app.securityManager.geminiApiKey
                            if (apiKey.isBlank()) {
                                summaryText = "Please configure Gemini API key in Settings."
                                isSummarizing = false
                                return@launch
                            }
                            val transcript = if (messageList.isNotEmpty()) {
                                messageList.joinToString("\n") { "${it.sender}: ${it.message}" }
                            } else {
                                "Raju: Boss kal meeting kitne baje hai?\nMe: 11 AM office mein.\nRaju: Theek hai, files ready rakhunga."
                            }
                            val res = app.geminiService.summarizeChat(transcript, apiKey)
                            isSummarizing = false
                            res.onSuccess {
                                summaryText = it
                                app.ttsManager.speak(it)
                            }.onFailure {
                                summaryText = "Summary failed: ${it.message}"
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSapphire),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("summarize_chat_button")
                ) {
                    Text(if (isSummarizing) "Summarizing with Gemini..." else "Summarize Recent Messages", color = NeonCyan)
                }

                summaryText?.let {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = SlateCard,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = it,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }

        // Voice Message Flow Test Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DeepSlate),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Voice Message Flow", color = GoldenAmber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "Command: \"<name> ko WhatsApp par message bhejo <text>\"",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                OutlinedTextField(
                    value = manualSendRecipient,
                    onValueChange = { manualSendRecipient = it },
                    label = { Text("Contact Name (e.g. Papa, Rohit)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = manualSendMessage,
                    onValueChange = { manualSendMessage = it },
                    label = { Text("Message Text") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val command = "$manualSendRecipient ko WhatsApp par message bhejo $manualSendMessage"
                        app.phoneCommander.processVoiceCommand(command)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger Voice Message Flow", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Recent Incoming Messages List
        Text("Recent WhatsApp Messages", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)

        if (messageList.isEmpty()) {
            Text(
                "No messages captured yet. Send a WhatsApp message to this phone to test live capture & spoken announcement.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        } else {
            for (msg in messageList.take(6)) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(msg.sender, color = EmeraldGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(msg.timestamp)),
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(msg.message, color = TextPrimary, fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
